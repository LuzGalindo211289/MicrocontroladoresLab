/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int Numero_carne = 211289;
    //Nombre es una cadena entonces se usa *
    char *Nombre = "Luz Aracely Galindo";
    //La varible char utiliza %s
    printf("Mi nombre es %s y mi número de carné es %d\n", Nombre, Numero_carne ); 
    return 0;
}
