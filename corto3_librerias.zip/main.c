/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//Llamamos a la libreria de operaciones matematicas
#include "operaciones.h"

const float  g = 3.14159; //Declaramos PI como una constante de 5 decimales

int main()
{
    float a, b;
    printf("Ingrese los 2 números que desea operar separados por un espacio: "); //Pedimos datos al usuario
    scanf ("%f %f", &a, &b); //lee varios tipos de datos
    int c = suma(a,b); //Suma
    int d = resta(a,b); //Resta
    int e = mult(a,b); //Multiplicación
    float f= divi(a,b); //División
    //Mostramos los resultados al usuario
    printf(" Suma: %d\n Resta: %d\n Multiplicación: %d\n División: %.2f\n Finalmente el valor de PI es: %.5f\n", c, d, e, f, g);
    return 0;
}
