#include "operaciones.h"
//Suma
int suma(float a, float b)
{
    return a + b;
    
}
//Resta
int resta(float a, float b)
{
    return a - b;
    
}

//Multiplicación
int mult(float a, float b)
{
    return a * b;
    
}

//División
float divi(float a, float b)
{
    return a / b;
    
}