#ifndef OPERACIONES_H
#define OPERACIONES_H

int suma (float a, float b); //Suma
int resta (float a, float b); //Resta
int mult (float a, float b); //Multiplicación
float divi (float a, float b); //División

#endif /*OPERACIONES_H*/