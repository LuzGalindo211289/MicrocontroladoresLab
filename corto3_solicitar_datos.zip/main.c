/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float F, C;
    printf("Ingrese la temperatura en Fahrenheit que convertirá a Celsius: ");
    //Permite leer varios tipos de datos
    scanf ("%f",  &F);
    //Ecauación de conversión
    C = (F - 32) * 5.0/9;
    printf("La temperatura en Celsius es %.3f\n", C);
    return 0;
}

