#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "jsmn.h"
#include "protocol.h"
#include "l298.h"
#include "registers.h"
#include "adc.h"
#include "timer.h"
#include "led.h"
#include "button.h"

enum
{
  STATE_PROTOCOL_IDL = 0,
  STATE_PROTOCOL_WAITING_DATA,
  STATE_PROTOCOL_RX_COMPLETE,
};

#define STX '*'
#define EXT '#'

#define MARK_MAGIC 0x55

#define SZ_RX_BUFFER 72

enum
{
    PROTOCOL_CMD_SET_MOTOR   = 'M',
    PROTOCOL_CMD_P_SEQUENCE  = 'P',
    PROTOCOL_CMD_MANUAL_MODE = 'C',
};

uint8_t __LOCAL_STATE = STATE_PROTOCOL_IDL;
uint8_t __MANUAL_MODE_ENABLE = 0;
uint8_t __RX_BUFFER[SZ_RX_BUFFER] = {0};
uint16_t __INDEX_RX_BUFFER = 0;


static int jsoneq(const char *json, jsmntok_t *tok, const char *s) 
{
  if (tok->type == JSMN_STRING && (int)strlen(s) == tok->end - tok->start &&
      strncmp(json + tok->start, s, (size_t)(tok->end - tok->start)) == 0) {
    return 0;
  }
  return -1;
}

uint8_t protocol_get_command(uint8_t * buffer, jsmntok_t * tokens, uint16_t len)
{
  uint16_t i;
  uint8_t cmd = 0x00;
  
  /* Loop over all keys of the root object */
  for (i = 1; i < len; i++)
  {
    if (jsoneq((const char *)buffer, &tokens[i], "c") == 0) {
      printf("Command: %.*s\r\n", tokens[i + 1].end - tokens[i + 1].start,
             buffer + tokens[i + 1].start);
      cmd = buffer[tokens[i + 1].start];
      break;
    }      
  }
  
  return cmd;
}

/*
 *{"c":"M","a":"S","t":"0"}#
 */
void cmd_set_motor(uint8_t * buffer, jsmntok_t * tokens, uint16_t len)
{
  uint8_t action = 0;
  uint16_t i = 0, time = 0;
  int16_t seq = -1;
  TypeSequence sequence;

  for (i = 1; i < len; i++)
  {
    if (jsoneq((const char *)buffer, &tokens[i], "a") == 0) {
      action = buffer[tokens[i + 1].start];
      i++;
    } 
    if (jsoneq((const char *)buffer, &tokens[i], "t") == 0) 
    {
      uint8_t number[8] = {0};
      
      memcpy(number, buffer + tokens[i + 1].start, (size_t)(tokens[i + 1].end - tokens[i + 1].start));
      time = (uint16_t)atoi((const char *)number);
      i++;
    } 
    if (jsoneq((const char *)buffer, &tokens[i], "s") == 0) 
    {
      uint8_t number[8] = {0};
      
      memcpy(number, buffer + tokens[i + 1].start, (size_t)(tokens[i + 1].end - tokens[i + 1].start));
      seq = atoi((const char *)number);
      i++;
    } 
  }
  
  printf("Set Action: %c, Time: %d\r\n", action, time);
  
  if (action!= 0)
  {
    sequence.registers.action = M_UNKNOW;
    sequence.registers.time   = time;
    
    switch(action)
    {
      case 'S': sequence.registers.action = CAR_ACTION_STOP; break;
      case 'F': sequence.registers.action = CAR_ACTION_FORWARD; break;
      case 'B': sequence.registers.action = CAR_ACTION_BACK; break;
      case 'L': sequence.registers.action = CAR_ACTION_LEFT; break;
      case 'R': sequence.registers.action = CAR_ACTION_RIGH; break;
    };
    
    /* Reproduce the action. */
    if (seq < 0)
    {
      led_set_mode(LED_MODE_UART);
      l298_set_motion(sequence.registers.action, sequence.registers.time);
    } 
  }
  
  if (seq >= 0)
  {
    /* Save in Memory */
    printf("Sequence Motor: %d\r\n", seq);
    
    sequence.registers.mark = MARK_MAGIC;
    
    register_write(seq, &sequence);
  }
}

/*
 *{"c":"P","s":"1","e":"5"}#
 */
void cmd_play_sequence(uint8_t * buffer, jsmntok_t * tokens, uint16_t len)
{
  int16_t seq_start = 0, seq_end = 0;
  int16_t i = 0;
  TypeSequence sequence;
  
  led_set_mode(LED_MODE_SEQUENCE);

  for (i = 1; i < len; i++)
  {
    if (jsoneq((const char *)buffer, &tokens[i], "s") == 0) 
    {
      uint8_t number[8] = {0};
      
      memcpy(number, buffer + tokens[i + 1].start, (size_t)(tokens[i + 1].end - tokens[i + 1].start));
      seq_start = (int16_t)atoi((const char *)number);
      i++;
    } 
    if (jsoneq((const char *)buffer, &tokens[i], "e") == 0) 
    {
      uint8_t number[8] = {0};
      
      memcpy(number, buffer + tokens[i + 1].start, (size_t)(tokens[i + 1].end - tokens[i + 1].start));
      seq_end = (int16_t)atoi((const char *)number);
      i++;
    } 
  }
  
  if (seq_start < seq_end)
  {
      for (i = seq_start; i <= seq_end; i++)
      {
          register_read(i, &sequence);
          
          if (sequence.registers.action != 0xFF)
          {
            printf("Seq: %d, Action: %c, Time: %d\r\n", i, sequence.registers.action, sequence.registers.time);
            
            l298_set_motion(sequence.registers.action, sequence.registers.time);
          }
      }
  }
}

/*
 * {"c": "C", "s": "E"}#
 * {"c": "C", "s": "D"}#
 */
void cmd_set_manual_mode(uint8_t * buffer, jsmntok_t * tokens, uint16_t len)
{
  uint8_t state = 0;
  uint16_t i = 0;

  for (i = 1; i < len; i++)
  {
    if (jsoneq((const char *)buffer, &tokens[i], "s") == 0) {
      state = buffer[tokens[i + 1].start];
      i++;
    }
  }
  
  if (state == 'E')
      __MANUAL_MODE_ENABLE = 1;
  else if (state == 'D')
      __MANUAL_MODE_ENABLE = 0;
}

void protocol_process( uint8_t * buffer, uint16_t len)
{
  jsmn_parser p;
  int16_t r;
  uint8_t cmd;

  /* We expect no more than 10 tokens */
  jsmntok_t t[12]; 
  
  jsmn_init(&p);
  
  r = jsmn_parse(&p, (const char *)buffer, len, t, sizeof(t) / sizeof(t[0]));  
  if (r < 0) 
  {
    printf("Failed to parse JSON: %d\n", r);
    
    return;
  }
  
  /* Assume the top-level element is an object */
  if (r < 1 || t[0].type != JSMN_OBJECT) 
  {
    printf("Object expected\n");
    return;
  }
  
  cmd = protocol_get_command(buffer, t, (uint16_t)r);
  
  if (cmd == PROTOCOL_CMD_SET_MOTOR)
  {
    printf("Setting Parameters motor.\r\n");
    
    cmd_set_motor(buffer, t, (uint16_t)r);
  }
  else if (cmd == PROTOCOL_CMD_P_SEQUENCE)
  {
    printf("Play Sequence.\r\n");
    
    cmd_play_sequence(buffer, t, (uint16_t)r);
  }
  else if (cmd == PROTOCOL_CMD_MANUAL_MODE)
  {
    cmd_set_manual_mode(buffer, t, (uint16_t)r);    
  }
}

void protocol_sent_byte(uint8_t input)
{
  if (__LOCAL_STATE == STATE_PROTOCOL_RX_COMPLETE)
      return;   
 
  if (input == STX)
  {
    __LOCAL_STATE = STATE_PROTOCOL_WAITING_DATA;
    __INDEX_RX_BUFFER = 0;
  }
  else if (input == EXT)
  {
    __LOCAL_STATE = STATE_PROTOCOL_RX_COMPLETE;
    __RX_BUFFER[__INDEX_RX_BUFFER] = 0;
  }
  else if (__INDEX_RX_BUFFER < (SZ_RX_BUFFER - 1))
  {
    __RX_BUFFER[__INDEX_RX_BUFFER++] = input;
  }  
}

void protocol_task(void)
{
  if (__LOCAL_STATE != STATE_PROTOCOL_RX_COMPLETE)
      return;
  
  protocol_process(__RX_BUFFER, __INDEX_RX_BUFFER);
  
  memset(__RX_BUFFER, 0, SZ_RX_BUFFER);
  
  __LOCAL_STATE = STATE_PROTOCOL_IDL;
}

#define MIN_M_STOP 0
#define MAX_M_STOP 340

#define MIN_M_FORWARD MAX_M_STOP + 1
#define MAX_M_FORWARD 680

#define MIN_M_BACK MAX_M_FORWARD + 1
#define MAX_M_BACK 1024

void manual_mode_task(void)
{
   int16_t i = 0;

   if (!__MANUAL_MODE_ENABLE)
      return;
   
   led_set_mode(LED_MODE_MANUAL);
   
   for (i = 0; i < CHANNEL_MAX; i++)
   {
      int16_t value  = (int16_t)adc_read((uint8_t)i);
      uint8_t  action = 0;
        
      delay_ms(50);
      
      if (value >= MIN_M_STOP && value <= MAX_M_STOP)
      {
        action = M_STOP;
      }
      else if (value >= MIN_M_FORWARD && value <= MAX_M_FORWARD)
      {
        action = M_FORWARD;
      }
      else if (value >= MIN_M_BACK && value <= MAX_M_BACK)
      {
        action = M_BACK;
      }
      
      l298_set((uint8_t)i, action, 0);
      if (button_check_event())
      {
        TypeSequence sequence;
        
        sequence.registers.action = action;
        sequence.registers.time   = 0;
        sequence.registers.mark   = MARK_MAGIC;
        
        register_write(1, &sequence);
      }
   }
}

void sequence_mode_task(void)
{
  if (__MANUAL_MODE_ENABLE)
    return;
  
  if (!button_check_event())
      return;
  
  led_set_mode(LED_MODE_SEQUENCE);
  delay_ms(250);
  
  int16_t i = 0;
  TypeSequence sequence;
  
  for (i = 1; i < MAX_REGISTERS; i++)
  {
    register_read(i, &sequence);
          
    if (sequence.registers.mark == MARK_MAGIC)
    {
      printf("Seq: %d, Action: %c, Time: %d\r\n", i, sequence.registers.action, sequence.registers.time);
            
      l298_set_motion(sequence.registers.action, sequence.registers.time);
      
      if (sequence.registers.action == CAR_ACTION_STOP)
      {
        break;
      }
    }
    else
    {
        printf("Register no valid: %02X\r\n", sequence.registers.mark);
        break;
    }
  }
  
  led_set_mode(LED_MODE_UART);
}
