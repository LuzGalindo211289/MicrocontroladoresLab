/* 
 * File:   uart.h
 * Author: gjaimes2
 *
 * Created on May 20, 2023, 1:33 PM
 */

#ifndef UART_H
#define	UART_H

#ifdef	__cplusplus
extern "C" {
#endif

void uart_init(void);

#ifdef	__cplusplus
}
#endif

#endif	/* UART_H */

