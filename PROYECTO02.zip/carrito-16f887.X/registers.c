#include <xc.h>

#include "registers.h"

#define MAX_SEQ 64
#define MIN_SEQ 1

uint8_t register_write(int16_t seq, TypeSequence * data)
{
    uint8_t * raw_data = (uint8_t *)&data->value;
    uint16_t  i, address, response;
           
    if (seq > MAX_SEQ && seq < MIN_SEQ)
        return 0;
    
    address = (uint16_t)(seq -1) * 4;
    
    for (i = 0; i < sizeof(TypeSequence); i++) 
    {
       response = memory_write(address + i, raw_data[i]);  
    }
    
    return (uint8_t)response;
}

void register_read(int16_t seq, TypeSequence * data)
{
    uint8_t * raw_data = (uint8_t *)&data->value;
    uint16_t  i, address;
           
    if (seq > MAX_SEQ && seq < MIN_SEQ)
        return;
    
    address = (uint16_t)(seq -1) * 4;
    
    for (i = 0; i < sizeof(TypeSequence); i++) 
    {
       raw_data[i] = memory_read(address + i);
    } 
}