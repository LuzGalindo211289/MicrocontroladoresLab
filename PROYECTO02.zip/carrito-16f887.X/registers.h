/* 
 * File:   registers.h
 * Author: gjaimes2
 *
 * Created on May 22, 2023, 8:38 PM
 */

#ifndef REGISTERS_H
#define	REGISTERS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "stdlib.h"
#include "memory.h"
    
typedef union __sequence
{
    struct
    {
      uint8_t  mark;
      uint8_t  action;
      uint16_t time;
    }registers;
    uint32_t value;
}TypeSequence;

#define MAX_REGISTERS MAX_SEQ/sizeof(TypeSequence)   

uint8_t register_write(int16_t seq, TypeSequence * data);
void    register_read(int16_t seq, TypeSequence * data);

#ifdef	__cplusplus
}
#endif

#endif	/* REGISTERS_H */

