/* 
 * File:   memory.h
 * Author: gjaimes2
 *
 * Created on May 20, 2023, 11:25 AM
 */

#ifndef MEMORY_H
#define	MEMORY_H

#ifdef	__cplusplus
extern "C" {
#endif

#define MAX_SEQ 64
#define MIN_SEQ 1 
  
void    memory_init(void);
uint8_t memory_write(uint16_t address, uint8_t data);
uint8_t memory_read(uint16_t address);

#ifdef	__cplusplus
}
#endif

#endif	/* MEMORY_H */

