#include <xc.h>
#include <stdio.h>
#include "uart.h"
#include "protocol.h"
#include "isr.h"
#include "led.h"

volatile char receivedChar = '\0';

void uart_isr();

/*
 * For BRGH=0:
 * SPBRG = (Fosc/(64 x Baud)) - 1
 *
 * For BRGH=1:
 * SPBRG = (Fosc/(16 x Baud)) - 1
 */

void uart_init(void)
{
  /* Set TX pin (RC6) as output */
  TRISCbits.TRISC6 = 0;
  /* Set RX pin (RC7) as input */
  TRISCbits.TRISC7 = 1;
  
  /* Configure USART control registers */
  /* Enable transmission */
  TXSTAbits.TXEN = 1;
  /* Set low baud rate speed */
  TXSTAbits.BRGH = 1;
  /* Enable serial port */
  RCSTAbits.SPEN = 1;
  /* Enable continuous reception */
  RCSTAbits.CREN = 1;
  
  /* Set baud rate to 9600 (assuming 8MHz oscillator frequency) */
  SPBRG = 52;
  
  isr_register_uart_handler(&uart_isr);
  
  /* Disable UART transmit interrupt */
  PIE1bits.TXIE = 0;
  /* Enable UART receive interrupt */
  PIE1bits.RCIE = 1;

  /* Enable USART and receiver */
  RCSTAbits.SPEN = 1;
  RCSTAbits.CREN = 1;

  /* Enable peripheral interrupts */
  INTCONbits.PEIE = 1;
  /* Enable global interrupts */
  INTCONbits.GIE = 1;
}

static void uart_putch(char data)
{
  /* Wait until transmit shift register is empty */
  while (!TXSTAbits.TRMT);
  /* Load data into transmit register */
  TXREG = data;              
}

void uart_isr()
{
   /* Read received data. */
  if (PIR1bits.RCIF)
  { 
    if (RCSTAbits.OERR)
    {
      RCSTAbits.CREN = 0;
      NOP();
      RCSTAbits.CREN = 1;
    }
    /* Read received data */
    receivedChar = RCREG;

    protocol_sent_byte(receivedChar);
    /* Clear the interrupt flag */
    PIR1bits.RCIF = 0;
  }
}

/* Redirect the printf function to use the putch function by overriding the __putchar function */
void putchar(char c)
{
  /* Call your custom put char function */
  uart_putch(c);  
}
