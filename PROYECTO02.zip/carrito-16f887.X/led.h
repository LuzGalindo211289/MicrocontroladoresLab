/* 
 * File:   led.h
 * Author: gjaimes2
 *
 * Created on May 21, 2023, 8:47 PM
 */

#ifndef LED_H
#define	LED_H

#ifdef	__cplusplus
extern "C" {
#endif
    
enum
{
  LED_MODE_UART = 0,
  LED_MODE_MANUAL,
  LED_MODE_SEQUENCE,
  LED_MODE_IO,
};

void led_init(void);
void led_set_mode(uint8_t mode);


#ifdef	__cplusplus
}
#endif

#endif	/* LED_H */

