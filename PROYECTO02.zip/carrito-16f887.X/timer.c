#include <xc.h>
#include "timer.h"
#include "isr.h"

uint32_t tick_10ms = 0;
uint32_t tick_250ms = 0;
uint32_t tick_500ms = 0;

uint8_t timer_event_250ms = 0;
uint8_t timer_event_500ms = 0;

void timer_0_isr(void);

void timer_init(void)
{
  /* Use Timer0 with internal instruction cycle clock */
  OPTION_REGbits.T0CS = 0;
  /* Enable Timer0 prescaler */
  OPTION_REGbits.PSA = 0;   
  /* Set Timer0 prescaler to 1:256 */
  OPTION_REGbits.PS = 0b111;

  /* Clear Timer0 register */
  TMR0 = 0;
  
  isr_register_timer_handler(&timer_0_isr);

  /* Enable Timer0 interrupt */
  INTCONbits.TMR0IE = 1;
  /* Enable global interrupts */
  INTCONbits.GIE = 1;
  
/*
 * Timer0_Value = 256 - ((Time_Interval / (4 * Prescaler)) * Fosc)
 * Timer0_Value = 256 - ((10 ms / (4 * 256)) * Fosc)
 * Timer0_Value = 256 - ((10 ms / (4 * 256)) * 8000000)
 *           = 256 - (31.25 * 312.5)
 *           = 256 - 9765.625
 *           = 246.375
 */
  
  TMR0 = 246;
}

void timer_0_isr(void)
{
  /* Timer0 interrupt */
  if (TMR0IF)
  {
    /* Clear Timer0 interrupt flag */ 
    TMR0IF = 0;
    
    tick_10ms++;
    tick_250ms++;
    
    if (tick_250ms == 25)
    {
      timer_event_250ms = 1;
      tick_250ms = 0;
      tick_500ms++;
    }
    
    if (tick_500ms == 2)
    {
      timer_event_500ms = 1;
      tick_500ms = 0;
    }
  }
}

void delay_ms(const uint32_t time)
{
  uint32_t tick_ref = tick_10ms;
  uint32_t tick_delay = time/10;
          
  while((tick_10ms - tick_ref) <  tick_delay);
}

#if SELFTEST_MAIN
uint8_t check_event(const uint8_t event)
{
  uint8_t response = 0;

  if (event == EVENT_TIME_250MS)
  {
      if (timer_event_250ms)
      {
        timer_event_250ms = 0;
        response = 1;
      }
  }
  else if (event == EVENT_TIME_500MS)
  {
      if (timer_event_500ms)
      {
        timer_event_500ms = 0;
        response = 1;
      } 
  }
  
  return response;
}

#endif
