/* 
 * File:   button.h
 * Author: gjaimes2
 *
 * Created on May 24, 2023, 10:55 PM
 */

#ifndef BUTTON_H
#define	BUTTON_H

#ifdef	__cplusplus
extern "C" {
#endif

void button_init(void);
uint8_t button_check_event(void);
void button_isr(void);


#ifdef	__cplusplus
}
#endif

#endif	/* BUTTON_H */

