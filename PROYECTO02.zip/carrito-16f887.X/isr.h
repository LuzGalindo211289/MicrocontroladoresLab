/* 
 * File:   isr.h
 * Author: gjaimes2
 *
 * Created on May 20, 2023, 4:10 PM
 */

#ifndef ISR_H
#define	ISR_H

#ifdef	__cplusplus
extern "C" {
#endif
    
typedef void (*isr_handler)(void);

void isr_register_uart_handler(isr_handler func);
void isr_register_timer_handler(isr_handler func);
void isr_register_button_handler(isr_handler func);

#ifdef	__cplusplus
}
#endif

#endif	/* ISR_H */

