/* 
 * File:   l298.h
 * Author: gjaimes2
 *
 * Created on May 21, 2023, 2:43 PM
 */

#ifndef L298_H
#define	L298_H

#ifdef	__cplusplus
extern "C" {
#endif

enum
{
  M1 = 0,
  M2,
  M3,
  M4,
  M5_UNKNOW
};

enum
{
  M_STOP,
  M_FORWARD,
  M_BACK,
  M_UNKNOW
};

enum
{
  CAR_ACTION_STOP    = 'S',
  CAR_ACTION_FORWARD = 'F',
  CAR_ACTION_BACK    = 'B',
  CAR_ACTION_LEFT    = 'L',
  CAR_ACTION_RIGH    = 'R',
};

void l298_init(void);
void l298_set(uint8_t motor, uint8_t action, uint16_t duration);
void l298_set_motion(uint8_t motion, uint16_t duration);

#ifdef	__cplusplus
}
#endif

#endif	/* L298_H */

