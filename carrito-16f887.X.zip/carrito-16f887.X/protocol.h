

#ifndef PROTOCOL_H
#define	PROTOCOL_H

#ifdef	__cplusplus
extern "C" {
#endif

void protocol_task(void);
void manual_mode_task(void);
void sequence_mode_task(void);
void protocol_sent_byte(uint8_t input);

#ifdef	__cplusplus
}
#endif

#endif	/* PROTOCOL_H */

