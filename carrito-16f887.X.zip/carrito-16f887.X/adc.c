

#include <xc.h>
#include "adc.h"

#define MASK_ADC_MAX_VALUE  0x03FF

void adc_init(void)
{
 /* Use VDD as the positive reference voltage */
 ADCON1bits.VCFG1 = 0;
 /* Use VSS as the negative reference voltage */
 ADCON1bits.VCFG0 = 0;
 /*Set like inputs (A03 - A0)*/
 TRISAbits.TRISA0 = 1;
 TRISAbits.TRISA1 = 1;
 TRISAbits.TRISA2 = 1;
 TRISAbits.TRISA3 = 1;
 
  ANSELbits.ANS0 = 1;     // Enable AN0 analog functionality
  ANSELbits.ANS1 = 1;     // Enable AN1 analog functionality
  ANSELbits.ANS2 = 1;     // Enable AN2 analog functionality
  ANSELbits.ANS3 = 1;     // Enable AN3 analog functionality
 /* Enable ADC Module */
 ADCON0bits.ADON = 1;
}

uint16_t adc_read(uint8_t channel)
{
   uint16_t value = 0;
   /* Select the channel */
   ADCON0bits.CHS = channel;
   /* Start the conversion */
   ADCON0bits.GO = 1;
   while (ADCON0bits.GO);

   value = (uint16_t)((ADRESH << 8) | ADRESL);

    /* Return the value */
   return (value & MASK_ADC_MAX_VALUE);
}
