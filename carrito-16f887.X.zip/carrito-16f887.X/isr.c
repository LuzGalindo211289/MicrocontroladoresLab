#include <xc.h>
#include "isr.h"

isr_handler isr_uart = (void *)0;
isr_handler isr_timer = (void *)0;
isr_handler isr_button = (void *)0;

void __interrupt() isr(void)
{
    if (isr_uart)
        isr_uart();
    
    if (isr_timer)
        isr_timer();

    if (isr_button)
        isr_button();
}

void isr_register_uart_handler(isr_handler func)
{
  isr_uart = func;
}

void isr_register_timer_handler(isr_handler func)
{
  isr_timer = func;
}

void isr_register_button_handler(isr_handler func)
{
  isr_button = func;
}
