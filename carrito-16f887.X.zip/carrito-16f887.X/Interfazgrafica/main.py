from car import *

controller = Car('COM1')

if controller.connect():
  controller.setPosition(Position.CAR_ACTION_RIGH.value, 0)
  controller.setPosition(Position.CAR_ACTION_FORWARD.value, 500, 1)
  controller.setPosition(Position.CAR_ACTION_LEFT.value,    500, 2)
  controller.setPosition(Position.CAR_ACTION_RIGH.value,    500, 3)
  controller.setPosition(Position.CAR_ACTION_STOP.value,    500, 4)
  controller.playSequence(1, 2)
  controller.setManualMode(False)
  controller.disconnect()
  del controller