 #SE IMPORTA LA LIBRERIA
import time
from tkinter import *
from PIL import Image
from PIL import ImageTk
import cv2
import imutils
from car import *
from tkinter import messagebox
# Import library and create instance of REST client.
from Adafruit_IO import Client
aio = Client('gal211289', 'aio_tDaw47TSLuKHCkloe3PhDUfkOAPL')


#-------
controller = Car('COM13')

#if controller.connect():
#  controller.setPosition(Position.CAR_ACTION_RIGH.value, 0)
#  controller.setPosition(Position.CAR_ACTION_FORWARD.value, 500, 1)
#  controller.setPosition(Position.CAR_ACTION_LEFT.value,    500, 2)
#  controller.setPosition(Position.CAR_ACTION_RIGH.value,    500, 3)
#  controller.setPosition(Position.CAR_ACTION_STOP.value,    500, 4)
#  controller.playSequence(1, 1)
#  controller.setManualMode(False)
#  controller.disconnect()
#  del controller
#-------
#---
# Funcion Visualizar
def visualizar():
    global raiz, frame, rgb, hsv, gray
    # Leemos la videocaptura
    if cap is not None:
        ret, frame = cap.read()

        # Si es correcta
        if ret == True:

            if (rgb == 1 and hsv == 0 and gray == 0):
                # Color BGR
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)


            # Rendimensionamos el video
            frame = imutils.resize(frame, width=200)

            # Convertimos el video
            im = Image.fromarray(frame)
            img = ImageTk.PhotoImage(image=im)

            # Mostramos en el GUI
            lblVideo.configure(image=img)
            lblVideo.image = img
            lblVideo.after(10, visualizar)

        else:
            cap.release()
            cv2.destroyAllWindows()

#---
# Funcion iniciar
def iniciar():
    global cap
    # Elegimos la camara
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    visualizar()
    print("SE INICIO EL CARRITO")

# Funcion finalizar
def finalizar():
    cap.release()
    cv2.destroyAllWindows()
    print("FIN DEL CARRITO")
#-------funcion correr hacia adelante-------
def on_action_forward(event):
  controller.setPosition(Position.CAR_ACTION_FORWARD.value, 0)
  print("SE MOVIO ADELANTE")
#----funcion Habilitar Modo Manual----
def Manual_mode_Ena(event):
    controller.setManualMode(True)
    aio.send_data('mensaje','Se activo el modo manual')
    print("SE Activo Modo Manual")
#-----funcion desabilitar Modo Manual--------
def Manual_mode_Desable(event):
 controller.setManualMode(False)
 aio.send_data('mensaje','Se desactivo el modo manual')
 print("SE Desactivo Modo Manual")
#----------funcion correr hacia atras----------------
def on_action_back(event):
  controller.setPosition(Position.CAR_ACTION_BACK.value, 0)
  print("SE MOVIO ATRAS")
#-----funcion de conectar el com---
def on_action_connect(event):
  if controller.connect() ==  False:
    messagebox.showinfo("Information","The Device is no connected")
#---FUNCION PARAR SECUENCIAS----
def on_action_stop(event):
    controller.setPosition(Position.CAR_ACTION_STOP.value, 0)
    print("PARO EL CARRITO")
    messagebox.showinfo("Informacion","Paro el carrito")
#--------funcion EPROM--------
def on_action_EEPROM(event):
    controller.playSequence(1, 1)
    print("Se ejecuto la secuencia")
    messagebox.showinfo("Informacion", "Se esta reproduciendo la secuencia manual")
#---FUNCION ADAFRUIT---------------------
def ADAFRUITAdela():
    data = aio.receive('boton')
    temp = str(data.value)
    if (temp == 'ON'):
        print("encendio LED")
        ada.bind('<Button-1>',on_action_forward)
        print("Se ejecuto la secuencia ADAFRUIT ADELANTE")
    elif (temp == 'OFF'):
        ada.bind('<Button-1>',on_action_stop)
        print("Se ejecuto la secuencia ADAFRUIT PARAR")
    else:
        print('Received value: {0}'.format(data.value))
    time.sleep(1)
    
# Variables
cap = None
hsv = 0
gray = 0
rgb = 1
detcolor = 0

#-------------------
#SE CREA LA VENTANA
raiz=Tk()        
      
miFrame=Frame(raiz,width=800,height=620 )
miFrame.pack()
#raiz.geometry("800x600")
raiz.title("Proyecto Gal211289")
raiz.resizable(0,0)
#raiz.iconbitmap('carros.ico')
miFrame.config(bg="skyblue")

#ABRIR IMAGEN Y ARREGLARLA
MImange= Image.open("coche.png")
resized = MImange.resize((100, 100),Image.ANTIALIAS)
new= ImageTk.PhotoImage(resized)



#LOS TEXTOS DE LA INTERFAZ
Label(miFrame, text="Opciones de carrito").place(x=350,y=25)
Label(miFrame, text="Controlar la dirección del carrito").place(x=320,y=75)
Label(miFrame, text="Envio de datos de la EEPROM").place(x=600,y=75)
Label(miFrame, text="Envio de datos de Adafruit").place(x=600,y=200)
Label(miFrame, text="Conectar").place(x=75,y=75)
Label(miFrame, text="Parar").place(x=75,y=200)
Label(miFrame, text="Opciones modo Manual").place(x=350,y=300)
Label(miFrame, text="Habilitar Modo Manual").place(x=75,y=380)
Label(miFrame, text="Desabilitar Modo Manual").place(x=600,y=380)

#LA IMAGEN DE LA INTERFAZ
Label(miFrame, image = new).place(x=350,y=450)

#ARRIBA--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImangeriba = Image.open("arriba.png")
resizedarriba = MImangeriba.resize((50, 50),Image.ANTIALIAS)
newarriba= ImageTk.PhotoImage(resizedarriba)
    #-----------------------------------
arriba = Button(raiz, text="iniciar", image=newarriba)
arriba.bind('<Button-1>', on_action_forward)
arriba.place(x=370,y=120)
#ABAJO--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImanabajo = Image.open("abajo.png")
resizedabajo = MImanabajo.resize((50, 50),Image.ANTIALIAS)
newabajo= ImageTk.PhotoImage(resizedabajo)
    #-----------------------------------
abajo = Button(raiz, text="iniciar", image=newabajo)
abajo.bind('<Button-1>', on_action_back)
abajo.place(x=370,y=200)
#INICIAR PROGRAMA--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImangeiniciar= Image.open("iniciar.png")
resizediniciar = MImangeiniciar.resize((60, 60),Image.ANTIALIAS)
newiniciar= ImageTk.PhotoImage(resizediniciar)
    #-----------------------------------
imagenIniciar = PhotoImage(file="iniciar.png")
iniciar = Button(raiz, text="iniciar", image=newiniciar, command=iniciar)
iniciar.bind('<Button-1>',on_action_connect)
iniciar.place(x=68,y=116)

#--------------------------------------------------------------
#Habilitar MANUAL--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImangmanualH= Image.open("iniciar.png")
resizedapagar = MImangmanualH.resize((70, 70),Image.ANTIALIAS)
newH= ImageTk.PhotoImage(resizedapagar)
    #-----------------------------------
H = Button(raiz, text="iniciar", image=newH)
H.bind('<Button-1>',Manual_mode_Ena)
H.place(x=85,y=450)

#--------------------------------------------------------------
#Desabilitar MANUAL--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImangmanualD= Image.open("iniciar.png")
resizedapagar = MImangmanualD.resize((70, 70),Image.ANTIALIAS)
newD= ImageTk.PhotoImage(resizedapagar)
    #-----------------------------------
H = Button(raiz, text="iniciar", image=newD)
H.bind('<Button-1>',Manual_mode_Desable)
H.place(x=620,y=450)
#--------------------------------------------------------------

#APAGAR PROGRAMA--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImangeapagar= Image.open("iniciar.png")
resizedapagar = MImangeapagar.resize((60, 60),Image.ANTIALIAS)
newapagar= ImageTk.PhotoImage(resizedapagar)
    #-----------------------------------
apagar = Button(raiz, text="iniciar", image=newapagar, command=finalizar)
apagar.bind('<Button-1>',on_action_stop)
apagar.place(x=70,y=250)

#ADAFRUIT PROGRAMA--------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImangeada= Image.open("ada.png")
resizedada = MImangeada.resize((100, 100),Image.ANTIALIAS)
newada= ImageTk.PhotoImage(resizedada)
    #-----------------------------------
ada = Button(raiz, text="iniciar", image=newada, command=ADAFRUITAdela)
ada.place(x=620,y=230)

#EEPROM --------------------------------------------
    #ARREGLAR IMAGEN-------------------
MImanee= Image.open("eeprom.png")
resizedee = MImanee.resize((80, 80),Image.ANTIALIAS)
newee= ImageTk.PhotoImage(resizedee)
    #-----------------------------------
eeprom = Button(raiz, text="iniciar", image=newee)
eeprom.bind('<Button-1>',on_action_EEPROM)
eeprom.place(x=640,y=108)
#--------------------------------------------------------------
#VIDEO---------------------------------------------------------
lblVideo = Label(raiz)
lblVideo.place(x=300,y=450)

raiz.mainloop()       #ENCICLA PARA CREAR EL LOOP DE LA VENTANA