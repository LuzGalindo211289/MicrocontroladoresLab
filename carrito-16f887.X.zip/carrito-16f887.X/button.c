#include <xc.h>
#include "button.h"
#include "timer.h"
#include "isr.h"

uint8_t _button_event = 0;

static void button_clr_wdog(void)
{
    __asm__ volatile("clrwdt");
}

void button_init(void)
{
  /* Configure RB0 pin as input */
  TRISDbits.TRISD4 = 1;
  /* Enable internal pull-up resistor for RB0 */
  //OPTION_REGbits.nRBPU = 0;
  /* Enable interrupt on change for RB0 */
  //IOCBbits.IOCB0 = 1;
  /* Enable global interrupts */
  //INTCONbits.GIE = 1;
  
  //isr_register_button_handler(&button_isr);
}

void button_isr(void)
{
  /* Check if the interrupt is from the RB0 pin */
  if (PORTDbits.RD4 == 1)
  {
      while(PORTDbits.RD4)
      {
        delay_ms(100);
 
        button_clr_wdog();
      }
    /* Button is pressed */ 
    _button_event = 1;  
  }
}

uint8_t button_check_event(void)
{
    uint8_t value = _button_event;
    
    _button_event = 0;

    return value;
}