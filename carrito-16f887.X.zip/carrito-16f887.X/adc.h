

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include "stdint.h"

enum
{
  CHANNEL_1 = 0,
  CHANNEL_2 = 1,
  CHANNEL_3 = 2,
  CHANNEL_4 = 3,
  CHANNEL_MAX = 4,
};

void     adc_init(void);
uint16_t adc_read(uint8_t channel);


#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

