#include <xc.h>
#include "led.h"

#define LED_UART        PORTCbits.RC5
#define LED_UART_TRIS   TRISCbits.TRISC5

#define LED_MANUAL      PORTAbits.RA4
#define LED_MANUAL_TRIS TRISAbits.TRISA4

#define LED_SEQUENCE      PORTAbits.RA5
#define LED_SEQUENCE_TRIS TRISAbits.TRISA5

#define LED_IO      PORTDbits.RD5
#define LED_IO_TRIS TRISDbits.TRISD5

static void led_all_off(void)
{
  LED_UART = 0;
  LED_MANUAL = 0;
  LED_SEQUENCE = 0;
  LED_IO = 0;
}

void led_init(void)
{
  LED_UART_TRIS = 0;
  LED_MANUAL_TRIS = 0;
  LED_SEQUENCE_TRIS = 0;
  LED_IO_TRIS = 0; 
}

void led_set_mode(uint8_t mode)
{
  led_all_off();
  
  switch(mode)
  {
      case LED_MODE_UART: LED_UART = 1;break;
      case LED_MODE_MANUAL: LED_MANUAL = 1;break;
      case LED_MODE_SEQUENCE: LED_SEQUENCE = 1;break;
      case LED_MODE_IO: LED_IO = 1;break;
  };
};
