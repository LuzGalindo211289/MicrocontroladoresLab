

#ifndef TIMER_H
#define	TIMER_H

#ifdef	__cplusplus
extern "C" {
#endif

enum
{
  EVENT_TIME_250MS = 0,
  EVENT_TIME_500MS = 0,
};    
    
void    timer_init(void);
void    delay_ms(const uint32_t time);
uint8_t check_event(const uint8_t event);

#ifdef	__cplusplus
}
#endif

#endif	/* TIMER_H */

