#include <xc.h>
#include <stdlib.h>

#include "memory.h"

#define MAX_ADDRESS 0XFF

void memory_init(void)
{
  /* EEPGD: Program/Data EEPROM Select bit */
  /* 0 = Accesses data memory */
  EECON1bits.EEPGD = 0;
}

uint8_t memory_write(uint16_t address, uint8_t data)
{
    if(address > MAX_ADDRESS)
        return 0;
        
    /* Set the EEPROM address */
    EEADR = (uint8_t)address; 
    /* Set the data byte to be written */   
    EEDATA = data;       
    
    /* Enable EEPROM write */
    EECON1bits.WREN = 1;
    /* Disable global interrupts during write operation */
    INTCONbits.GIE = 0;
    
    /* Perform the write sequence */
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    
    /* Re-enable global interrupts */
    INTCONbits.GIE = 1;
    /* Disable EEPROM write */
    EECON1bits.WREN = 0;    
    
    while (EECON1bits.WR); 
    
    return 1;
}

uint8_t memory_read(uint16_t address)
{
  if(address > MAX_ADDRESS)
      return 0xFF;

  /* Set the EEPROM address */
  EEADR = (uint8_t)address;      
  
  /* Start EEPROM read operation */
  EECON1bits.RD = 1;    

  /* Return the data byte read */
  return EEDATA;        
}
