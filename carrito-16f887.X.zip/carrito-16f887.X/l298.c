#include <xc.h>
#include "l298.h"
#include "timer.h"
#include "config.h"

#define CRTL1_IN1 PORTDbits.RD0
#define CRTL1_IN2 PORTDbits.RD1
#define CRTL1_IN3 PORTDbits.RD2
#define CRTL1_IN4 PORTDbits.RD3

#define CRTL1_IN1_TRIS TRISDbits.TRISD0
#define CRTL1_IN2_TRIS TRISDbits.TRISD1
#define CRTL1_IN3_TRIS TRISDbits.TRISD2
#define CRTL1_IN4_TRIS TRISDbits.TRISD3


#define CRTL2_IN1 PORTDbits.RD6
#define CRTL2_IN2 PORTDbits.RD7
#define CRTL2_IN3 PORTCbits.RC3
#define CRTL2_IN4 PORTCbits.RC4

#define CRTL2_IN1_TRIS TRISDbits.TRISD6
#define CRTL2_IN2_TRIS TRISDbits.TRISD7
#define CRTL2_IN3_TRIS TRISCbits.TRISC3
#define CRTL2_IN4_TRIS TRISCbits.TRISC4

#define PWM_SIGNAL_ENAB      PORTCbits.RC1
#define PWM_SIGNAL_ENAB_TRIS TRISCbits.TRISC1



static void init_l298_pwm(void)
{
  /* Set CCP2 pin as output */
  PWM_SIGNAL_ENAB_TRIS = 0;
  
  /* http://eng-serve.com/pic/pic_pwm.html */
  /*
  * PWM Register Values
  * Oscillator Frequency Fosc = 8000000
  * Clock Frequency Fclk = 2000000
  * PWM Freq = 10000 desired...actual: 10000
  * Prescaler Value = 1
  * PR2 = 199
  * Maximum duty value = 800
  * Requested Duty Value = 400
  *
  * Code Provided AS IS....Use at your own risk!
  */
  
  T2CON   = 0b00000111; // prescaler + turn on TMR2;
  PR2     = 0b00001100;
  CCPR2L  = 0b01100100;  // set duty MSB
  CCP2CON = 0b00001100; // duty lowest bits + PWM mode
}

void l298_init(void)
{
    /* Initialize controller number #1 */
    CRTL1_IN1_TRIS = 0;
    CRTL1_IN2_TRIS = 0;
    CRTL1_IN3_TRIS = 0;
    CRTL1_IN4_TRIS = 0;
    
    CRTL1_IN1 = 0;
    CRTL1_IN2 = 0;
    CRTL1_IN3 = 0;
    CRTL1_IN4 = 0;
    
    /* Initialize controller number #2 */
    CRTL2_IN1_TRIS = 0;
    CRTL2_IN2_TRIS = 0;
    CRTL2_IN3_TRIS = 0;
    CRTL2_IN4_TRIS = 0;

    CRTL2_IN1 = 0;
    CRTL2_IN2 = 0;
    CRTL2_IN3 = 0;
    CRTL2_IN4 = 0;
    
    init_l298_pwm();
}


void l298_set(uint8_t motor, uint8_t action, uint16_t duration)
{
    switch(motor)
    {
        case M1:
        {
           if (action == M_STOP)
           {
             CRTL1_IN1 = 0;
             CRTL1_IN2 = 0;
           }
           else if (action == M_FORWARD)
           {
             CRTL1_IN1 = 1;
             CRTL1_IN2 = 0;               
           }
           else if (action == M_BACK)
           {
             CRTL1_IN1 = 0;
             CRTL1_IN2 = 1;            
           }
        }break;
        case M2:
        {
           if (action == M_STOP)
           {
             CRTL1_IN3 = 0;
             CRTL1_IN4 = 0;           
           }
           else if (action == M_FORWARD)
           {
             CRTL1_IN3 = 1;
             CRTL1_IN4 = 0;                  
           }
           else if (action == M_BACK)
           {
             CRTL1_IN3 = 0;
             CRTL1_IN4 = 1;              
           }        
        }break;
        case M3:
        {
           if (action == M_STOP)
           {
             CRTL2_IN1 = 0;
             CRTL2_IN2 = 0;           
           }
           else if (action == M_FORWARD)
           {
             CRTL2_IN1 = 1;
             CRTL2_IN2 = 0;               
           }
           else if (action == M_BACK)
           {
             CRTL2_IN1 = 0;
             CRTL2_IN2 = 1;            
           }        
        }break;
        case M4:
        {
           if (action == M_STOP)
           {
             CRTL2_IN3 = 0;
             CRTL2_IN4 = 0;            
           }
           else if (action == M_FORWARD)
           {
             CRTL2_IN3 = 1;
             CRTL2_IN4 = 0;                
           }
           else if (action == M_BACK)
           {
             CRTL2_IN3 = 0;
             CRTL2_IN4 = 1;            
           }        
        }break;
    }
    
    
    if(duration > 0)
      delay_ms(duration);
}

void l298_set_motion(uint8_t motion, uint16_t duration)
{
    switch(motion)
    {
        case CAR_ACTION_STOP:
        {
            l298_set(M1, M_STOP, 0);
            l298_set(M2, M_STOP, 0);
            l298_set(M3, M_STOP, 0);
            l298_set(M4, M_STOP, 0);
        }break;
        case CAR_ACTION_FORWARD:
        {
            l298_set(M1, M_FORWARD, 0);
            l298_set(M2, M_FORWARD, 0);
            l298_set(M3, M_FORWARD, 0);
            l298_set(M4, M_FORWARD, 0);
        }break;
        case CAR_ACTION_BACK:
        {
            l298_set(M1, M_BACK, 0);
            l298_set(M2, M_BACK, 0);
            l298_set(M3, M_BACK, 0);
            l298_set(M4, M_BACK, 0);
        }break;
        case CAR_ACTION_LEFT:
        {
            l298_set(M1, M_STOP, 0);
            l298_set(M2, M_FORWARD, 0);
            l298_set(M3, M_FORWARD, 0);
            l298_set(M4, M_FORWARD, 0);            
        }break;
        case CAR_ACTION_RIGH:
        {
            l298_set(M1, M_FORWARD, 0);
            l298_set(M2, M_STOP, 0);
            l298_set(M3, M_FORWARD, 0);
            l298_set(M4, M_FORWARD, 0);
        }break;
    };
    
     if(duration > 0)
      delay_ms(duration);
}