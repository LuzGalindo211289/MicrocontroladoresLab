
#include <xc.h>
#include <stdio.h>

#include "adc.h"
#include "memory.h"
#include "uart.h"
#include "timer.h"
#include "protocol.h"
#include "l298.h"
#include "led.h"
#include "button.h"

#include "config.h"

void clr_wdog()
{
    __asm__ volatile("clrwdt");
}

void main(void) 
{
    /* Initialize ADC Module */
    adc_init();

    /* Initialize memory */
    memory_init();

    /* Initialize timer */
    timer_init();

    /* Initialize serial port */
    uart_init();
    
    /* Initialize motors controller */
    l298_init();
    
    /* Initialize led */
    led_init();
    
    led_set_mode(LED_MODE_UART);
    
    /* Initialize button */
    button_init();
    
    while (1)
    { 
        
      button_isr();

      protocol_task();
      
      manual_mode_task();
      
      sequence_mode_task();
      
      clr_wdog();
    }
    
    return;
}
