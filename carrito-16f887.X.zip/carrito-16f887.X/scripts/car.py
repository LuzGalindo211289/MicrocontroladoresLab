import json
import serial
import threading
from   enum import Enum

class Position(Enum):
  CAR_ACTION_STOP    = 'S'
  CAR_ACTION_FORWARD = 'F'
  CAR_ACTION_BACK    = 'B'
  CAR_ACTION_LEFT    = 'L'
  CAR_ACTION_RIGH    = 'R'

class Car:

  # init method or constructor
  def __init__(self, port):
    self.name = port

  def __del__(self):
    self.disconnect()

  def connect(self):
    self.is_connected  = True

    try:
      self.interface = serial.Serial(self.name, 9600)
      self.interface.open()
      self.__listenPort()
    except:
      self.is_connected  = False

    return self.is_connected

  def disconnect(self):
    if self.is_connected == True:
      self.interface.close()
      self.is_connected = False

    return True

  def __getFrame(self, object):
    return '*' + json.dumps(object, separators=(',', ':')) + '#'

  def __poll(self):
    while self.interface:
      if self.interface.in_waiting:
        print(self.interface.read_all())

  def __listenPort(self):
    threading.Thread(target=self.__poll).start()

  def setManualMode(self, state):

    if self.is_connected == False:
      return False

    command = {}
    command['c'] = 'C'

    if state == True:
      command['s'] = 'E'
    else:
      command['s'] = 'D'

    print(self.__getFrame(command))
    self.interface.write(self.__getFrame(command))

    return True

  def setPosition(self, position, time, sequence = 0):

    if self.is_connected == False:
      return False

    command = {}
    command['c'] = 'M'
    command['a'] = position
    command['t'] = str(time)

    if sequence > 0 :
      command['s'] = str(sequence)

    print(self.__getFrame(command))
    self.interface.write(self.__getFrame(command))

    return True

  def playSequence(self, start, end):

    if self.is_connected == False:
      return False

    command = {}
    command['c'] = 'P'
    command['s'] = str(start)
    command['e'] = str(end)

    print(self.__getFrame(command))
    self.interface.write(self.__getFrame(command))

    return True
