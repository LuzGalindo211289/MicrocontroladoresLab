/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
      int N = 5; //cantidad de valores del array
      int array[N];  //creamos el array
      int *ptr = array; //creamos un puntero
    
    //Solicitamos al usuario los 5 datos
      printf("Ingrese %d numeros separados por un espacio:\n", N);
      for (int i=0; i<N; i++) 
      {
          //llenamos el array
          scanf("%d", &array[i]);
      }

      printf("Los valores del array multiplicados por 2 son:\n");
      for (int i=0; i<N; i++) 
      {
          //Multiplicamos por 2 el array y mostramos el resultado
          printf("%d\n", (*ptr)*2);
          ptr++;
      }

      return 0;
}
