/*
 * File:   config_pwm.c
 * Author: Luz Galindo
 *
 * Created on 10 de abril de 2023, 01:59 PM
 */

#include "pwm.h"
#include <xc.h> 
#define valPR2 194 // valor para 20Hz y prescaler de 16

void Inicializar_PWM(void)
{
    TRISC = 0X02;     // Configura el Puerto C como salida
    CCP1CON = 0X1C;   // Configura CCP1 para PWM
    CCP2CON = 0b1100;   // Configura CCP2 para PWM
    T2CON = 0b00000111; // Configura Timer2 para PWM
    PR2 = valPR2;      // Configura el periodo del PWM
    
    Configurar_CicloDeTrabajo_PWM(0);  // Inicializa el ciclo de trabajo en 0%
}

void Configurar_CicloDeTrabajo_PWM(unsigned int duty_cycle)
{
    CCPR1L = (unsigned char)(duty_cycle >> 2);   // Configura el ciclo de trabajo de CCP1
    CCP1CONbits.DC1B1 = (duty_cycle & 0b10) >> 1;
    CCP1CONbits.DC1B0 = duty_cycle & 0b01;
    
    CCPR2L = (unsigned char)(duty_cycle >> 2);  // Configura el ciclo de trabajo de CCP2
    CCP2CONbits.DC2B1 = (duty_cycle & 0b10) >> 1;
    CCP2CONbits.DC2B0 = duty_cycle & 0b01;
}