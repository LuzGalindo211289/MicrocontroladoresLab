

/* 
 * File:   pwm_config
 * Author: Luz Galindo
 * Comments:  Configuraci�n del PWM
 * Revision history: 10 de abril de 2023
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef pwm_H
#define	pwm_H

#include <xc.h> // include processor files - each processor file is guarded.  

void Inicializar_PWM(void);
void Configurar_CicloDeTrabajo_PWM(unsigned int duty_cycle);

#endif


