
#ifndef pwm1_H
#define pwm1_H 

#include <xc.h>

void Inicializar_PWM(void);
void Configurar_CicloDeTrabajo_PWM(unsigned int duty_cycle);

#endif