/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int N, i;
    int Primero= 0, Segundo = 1, Tercero;

    printf("Ingrese el numero de terminos de la serie de Fibonacci: ");
    //Leemos varios tipos de datos
    scanf("%d", &N);
    printf("Los %d primeros terminos de la serie de Fibonacci son:\n", N);
    
    
    for (i=0; i<N; i++) //comienza en 0 y termina en N-1
    {
        if (i<=1)
            Tercero=i;
        else
        {
            //cada número es igual a la suma de sus dos anteriores
            Tercero = Primero + Segundo;
            Primero = Segundo;
            Segundo = Tercero;
        }
        printf("%d ", Tercero); //Muestra el resultado
    }
    return 0;
}


